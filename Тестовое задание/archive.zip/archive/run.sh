#!/bin/bash
java -jar xml-converter.jar "$@"